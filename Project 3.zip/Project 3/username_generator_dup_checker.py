#Import Section

from datetime import date   #import this for Date
import getpass              #import this for User

#Flower Box Section

#########################################################
#                                                       
#   Name:  Braeden Loe                      
#   Date:  01/25/2023
#   Program Description:
#
# Program takes lists regarding employee first name, last name, and year born in order to generate a username. There are a total of 5 first names, 5 last names, and 5 birth dates that will be the elements of the usernames. 
# A dictionary is used to store the information of our created usernames that is made up of the first name, last name, year born data within our input section. 
# This program will have duplicate lists that will be negated in the print section of our program. 
# 
#   
#
#                                                       
#########################################################

#Variables section

username_list = [] #This is the variable that generates my username list.

username_sorted_list = [] #This is the variable that sorts my generated username list. This can be in alphabetical order or in order of dates.

employee_data_dictonary = {} #This variable has key value pairs in which the dictonary will retain the order of variables that are being defined. 

all_employee_data_in_tuple_list = [] #Declared variable for all employee data in tuple list. 

first_name = "" #Empty string first name variable. 

last_name = "" #Empty string for last name variable. 

year_born = "" #Empty string for year born variable.

is_this_correct = "" #Empty string variable to ask user if informnation is correct.

yes_list = ["Yes", "YES", "yes", "Y", "y"] #This is the list of all possible user answers in uppercase, lowercase, and all upercase. Anything that is not in this list will be considered NO.
    

#Functions section

    #Starting on project 4 all functions created will be in this section

#Input section

first_name_list = ["Braeden","Harry","Peter","Oliver","Marcel"] #This is the list of all first name elements. 

last_name_list = ["Loe","Loe","Jacobs","Shoemaker","Tejeda"] #This is the list of all the last name elements.

year_born_list = ["1993","1993","1998","1999","2000"] #This is a list of all the birth year elements.

print("Enter the information below to create a username for the network") #This prints the information below to create the username. 
while len(all_employee_data_in_tuple_list) < 5: #Tuple list for variables above greater than 5 no variables entered. 
    while len(first_name) < 2: #First name nested loop, value must be greater than 2. First name was declared and less than 2 above.
        first_name = input("Enter the employee's first name: ") #Input command for user to enter their first name value greater than 2.
    while len(last_name) < 2: #Last name nested loop value must be greater than 2.  Last name was declared and less than 2 above.
        last_name = input("Enter the employee's last name: ") #Last name input command value is greater than 2.
    while len(year_born) < 4:  #Year born nested loop value is greater than 4 for the year date.
        year_born = input("Enter the employee's year born: ") #Input command for employee year born. 
    
    print("you entered " + first_name + " " + last_name + " " + year_born + " Is this correct ") #Print statement asking user if first name, last name, year born information was entered correctly. Used with concanations. 
    is_this_correct = input(" Yes or No: ") #Input for user yes or no. Anything not in list is a no regardless of input, it must be in the list.

    if(is_this_correct in yes_list): #User input the correct information.  
        employee_data = (first_name , last_name, year_born) #info entered by user displayed in typle list converted to emplpoyee data. 
        all_employee_data_in_tuple_list.append(employee_data) 
        first_name = "" #Reset value for first name.
        last_name = "" #Reset value for last name. 
        year_born = "" #Rest value for year born. 
    

    else: #If user did not input information needed and instead put in something else. 
        first_name = "" #Reset value for first name.
        last_name = "" #Reset value for last name. 
        year_born = "" #Rest value for year born. 
        
       
    
#Process section
for employee_data in all_employee_data_in_tuple_list: #This is our for loop in which all the lines of code will be under our for loop.
    
    employee_first_name = employee_data[0]   #Contains the first name data of the 5 employee name elements.
    
    employee_last_name = employee_data[1] #Contains the last name data for the 5 employee name elements. 
    
    employee_year_born = employee_data[2] #Contains the year born data within the 5 employee name elements. 

    first_initial = employee_first_name[0].lower() #This will display the first initial of the emplpoyee in lowercase format.
    
    employee_last_name = employee_last_name.lower() #This will display the last name initial in lowercase format.

    Year_born_last_two_digits = employee_year_born[-2:] #This will display the last two digits of the year born.

    username = first_initial+employee_last_name+Year_born_last_two_digits #This is the concanation that will bind the information above to create our username.

    username_list.append(username) #This function takes username lists and appends the end of it.

    employee_data_dictonary[username] = employee_data #This is the dictonary that will display employee usernames. 
    

username_test_set = set(username_list) #Test set for generation of usernames including duplicates. 

username_no_dups_list = list(username_test_set) #This identifies the duplicate usernames. 

for username in username_no_dups_list: #This is the loop command that 
    
    username_sorted_list.append(username) #Appends the end of sorted list usernames.

username_sorted_list.sort() #Sorts username list.






#Output section

print(getpass.getuser()) #Print command for username.

print(date.today()) #Print command for displaying date as shown on user's OS.

print(all_employee_data_in_tuple_list) #Prints tuple list of all employee data.

print(username_list) #Prints user name list including duplicates.

print(username_test_set) #Prints username list without order. 

print(employee_data_dictonary) #Prints employee data list along with username information

print(username_sorted_list) #Prints final product of all usernames in order and without duplications. 

